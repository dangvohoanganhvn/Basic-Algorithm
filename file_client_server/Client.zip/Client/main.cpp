#include "Client.h"
#include <thread>
#include <mutex>
#include <unistd.h>
#include <fstream>
#include <boost/asio.hpp>
#include <boost/filesystem.hpp>

using namespace std;
mutex   mtx;

void Terminal(std::vector<Client*> client_list);

void Rcv(Client* client);

bool is_digit(const char value) { return std::isdigit(value); }
bool is_numeric(const std::string& value) { return std::all_of(value.begin(), value.end(), is_digit); }
void ThreadCreateRcv(boost::asio::thread_pool &threads_master,std::vector<Client*>& client_list);
void ThreadCreateSend(boost::asio::thread_pool &threads_master,std::vector<Client*>& client_list);

void Send(Client* client);
string data;
bool file_is_set=false;

int main(int argc, char const *argv[])
{


    std::vector<Client*> client_list;
    std::string ip_addr="localhost";
    int port=8081;
    fstream input;
    int num_client;


    cout<<"Input the number of clients "<<endl;
    std::string num;
    getline(std::cin, num);
    if(is_numeric(num))
    {
        num_client = std::stoi(num);
    }
    else
    {
        cout<<"Please input a number"<<endl;
        exit(1);
    }
    boost::asio::thread_pool pool(num_client*2+1);

    std::string dir;

    for(int i=0;i<num_client;i++)
    {
        Network_Interface* network =new Client();
        auto client=dynamic_cast<Client*>(network);
        //client->SetSrcIdSend(i+1);
        //cout<<"My id is "<<client->GetMySourceIdSend()<<endl;
        client->Create_Socket(AF_INET, SOCK_STREAM, 0);
        client->Connect(AF_INET,ip_addr,port);
        client_list.push_back(client);
    }

    ThreadCreateSend(pool,client_list);
    ThreadCreateRcv(pool,client_list);


    boost::asio::post(pool,
                      [&]()
    {
        Terminal(client_list);
    });

    pool.join();
    // pool_test.join();


    return 0;
}

void Terminal(std::vector<Client*> client_list)
{
    int size_client_list=client_list.size();
    string test="Test data";
    fstream input;
    bool stop=false;
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 50;
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    std::cout<<"Input the directory of the file"<<std::endl;
    while(!stop)
    {

        fd_set read;
        FD_ZERO(&read);
        FD_SET(0,&read);
        //select 1 cin ready to read input
        if(select(1,&read,nullptr,nullptr,&tv) == -1)
        {
            perror("select :");
        }
        if(FD_ISSET(0,&read))
        {

            std::string userInput;
            getline(std::cin,userInput);
            std::lock_guard<std::mutex> lock(mtx);
            try
            {
                if (boost::filesystem::exists(userInput))
                {
                    if (boost::filesystem::is_regular_file(userInput))
                    {

                        input.open(userInput);///Users/cpu11905/Desktop/test.txt

                        string line;
                        stop=true;
                        while (!input.eof())
                        {
                            getline(input, line);
                            data += line+"\n";
                        }

                        input.close();


                        file_is_set=true;
                        cout<<"File is set"<<endl;
                        // mtx.unlock();

                        //avoid full of memory due to unblock socket
                        //);
                    }

                }
                else
                {
                    cout << userInput << " does not exist\n";
                    std::cout<<"Input the directory of the file Again"<<std::endl;
                    // std::this_thread::sleep_for(std::chrono::milliseconds(1));

                }
            }

            catch (const boost::filesystem::filesystem_error& ex)
            {
                cout << ex.what() << '\n';
            }

        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }

    }


}

void Rcv(Client* client)
{

    fd_set listener;
    FD_ZERO(&listener);
    FD_SET(client->GetMySocket(),&listener);
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 50;
    while(1){
        if(select(client->GetMySocket()+1,&listener, nullptr,nullptr,nullptr) == -1){
            perror("select");
        }
        if(FD_ISSET(client->GetMySocket(),&listener))
        {
            mtx.lock();
            int num_rcv=client->Recieve_Msg(client->GetMySocket());
            //  mtx.unlock();
            // std::this_thread::sleep_for(std::chrono::seconds(1));
            if(num_rcv==0)
            {
                std::cout<<"Connection was closed"<<std::endl;
                close  (client->GetMySocket());
                break;
            }
            else if (num_rcv>0 && client->GetMsgRcv()->m_type==AUTHEN) {


                client->SetSrcIdSend(client->GetMsgRcv()->m_des_id);

                cout<<"Your id is "<<client->GetMsgRcv()->m_des_id<<endl;

            }
            mtx.unlock();
            std::this_thread::sleep_for(std::chrono::milliseconds(10));

        }
    }
}

void ThreadCreateRcv(boost::asio::thread_pool &threads_master,std::vector<Client*>& client_list)
{

    for (auto&client:client_list) {
        boost::asio::post(threads_master,
                          [&]()
        {
            Rcv(client);
        });
    }

}
void ThreadCreateSend(boost::asio::thread_pool &threads_master,std::vector<Client*>& client_list)
{
    int i=0;
    for(i=0;i<client_list.size();i++)
    {
        //cout<<"test"<<endl;
        if(i%2==0)
        {

            boost::asio::post(threads_master,
                              [=]()
            {
                //cout<<"test "<<i<<endl;
                //  cout<<"test size "<<client_list.size()<<endl;
                Send(client_list[i]);
            });
        }
    }

}
void Send(Client* client)
{
    while(1)
    {
        mtx.lock();
        bool file_set=file_is_set;

        if(file_set)
        {
            mtx.unlock();

            string data_send=data;
            auto src=client->GetMySourceIdSend();
            auto des=client->GetMySourceIdSend()+1;
            auto socket =client->GetMySocket();
            client->SetDataSend(data_send,FILE,src,des);
            client->Send_Msg(socket);


            break;
        }
        mtx.unlock();
    }
}

