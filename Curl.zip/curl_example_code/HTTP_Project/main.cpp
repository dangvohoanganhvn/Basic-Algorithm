/**
 * Compile like this: g++ -o HTTPDownloaderExample main.cpp httpdownloader.cpp -lcurl
 */

#include "httpdownloader.h"
#include <iostream>
#include <string>
int main(int argc, char** argv)
{


    HTTPDownloader downloader;
    std::string content = downloader.download(argv[1]);
    std::cout << content << std::endl;
}
