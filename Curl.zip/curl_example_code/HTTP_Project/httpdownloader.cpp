
#include "httpdownloader.h"
#include <curl/curl.h>
#include <curl/easy.h>
#include <curl/curlbuild.h>
#include <sstream>
#include <iostream>
using namespace std;
size_t write_data(void *buffer, size_t size, size_t nmemb, void *output)
{
    string data((const char*) buffer, (size_t) size * nmemb);
    *((stringstream*) output) << data << endl;
    return size * nmemb;
}
HTTPDownloader::HTTPDownloader() {
    curl = curl_easy_init();
}
HTTPDownloader::~HTTPDownloader() {
    // curl_easy_perform(curl);
    curl_easy_cleanup(curl);
}
string HTTPDownloader::download(const std::string& url) {
    FILE *file=fopen("/Users/cpu11905/Desktop/data/header","wb");
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L); // tell the lib follow the redirection automatically
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1); //Prevent "longjmp causes uninitialized stack frame" bug
    curl_easy_setopt(curl, CURLOPT_HEADER, 1L);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, file);
    //    /* Sets the contents of the Accept-Encoding: header sent in an HTTP request, and enables decoding of a response when a Content-Encoding: header is received.
    //     * Three encodings are supported: identity, meaning non-compressed, deflate which requests the server to compress its response using the zlib algorithm, and gzip which requests the gzip algorithm.
    //     * If a zero-length string is set like "", then an Accept-Encoding: header containing all built-in supported encodings is sent.
    //     * Set this option to NULL to explicitly disable it, which makes libcurl not send an Accept-Encoding: header and not decompress contents automatically.*/
    curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "deflate");

    std::stringstream out;
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &out);
    /* Perform the request, res will get the return code */
    CURLcode res = curl_easy_perform(curl);
    /* Check for errors */
    if (res != CURLE_OK)
    {
        fprintf(stderr, "curl_easy_perform() failed: %s\n",
                curl_easy_strerror(res));
    }
    // file->close();
    fclose(file);
    return out.str();
}
