
#include "httpdownloader.h"
#include <curl/easy.h>
#include <curl/curlbuild.h>
#include <chrono>
#include <thread>

#include <iostream>
using namespace std;
size_t write(void *buffer, size_t size, size_t nmemb, void *output)
{
    string data((const char*) buffer, (size_t) size * nmemb);
    *((stringstream*) output) << data;
    return size * nmemb;
}
HTTPDownloader::HTTPDownloader()
{

}
HTTPDownloader::~HTTPDownloader() {
    curl_multi_cleanup(multi_handle);
    for(auto i:handles)
    {
        curl_easy_cleanup(i);
    }

}
void HTTPDownloader::download(const std::string& url,std::stringstream& data) {

    auto curl=Add_New_Action();
   // curl_easy_setopt(curl, CURLOPT_HEADERDATA, file);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HEADER, 1L);

    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L); // tell the lib follow the redirection automatically
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1); //Prevent "longjmp causes uninitialized stack frame" bug
                       //    /* Sets the contents of the Accept-Encoding: header sent in an HTTP request, and enables decoding of a response when a Content-Encoding: header is received.
    //     * Three encodings are supported: identity, meaning non-compressed, deflate which requests the server to compress its response using the zlib algorithm, and gzip which requests the gzip algorithm.
    //     * If a zero-length string is set like "", then an Accept-Encoding: header containing all built-in supported encodings is sent.
    //     * Set this option to NULL to explicitly disable it, which makes libcurl not send an Accept-Encoding: header and not decompress contents automatically.*/
    //curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "deflate");

    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &data);
    /* Perform the request, res will get the return code */
    Init_New_Curl(curl);
}

CURL* HTTPDownloader::Add_New_Action()
{
    handles.push_back(curl_easy_init());
    num_curl++;
    return handles.back();
}

void HTTPDownloader::Init_Multi_Curl()
{
    multi_handle = curl_multi_init();
}

void HTTPDownloader::Init_New_Curl(CURL* curl)
{


    curl_multi_add_handle(multi_handle, curl);

    /* we start some action by calling perform right away */
    curl_multi_perform(multi_handle, &still_running);
}

void HTTPDownloader::Exec()
{
    while(still_running)
    {

        struct timeval timeout;
        int rc; /* select() return code */
        CURLMcode mc; /* curl_multi_fdset() return code */

        fd_set fdread;
        fd_set fdwrite;
        fd_set fdexcep;
        int maxfd = -1;

        long curl_timeo = -1;

        FD_ZERO(&fdread);
        FD_ZERO(&fdwrite);
        FD_ZERO(&fdexcep);

        /* set a suitable timeout to play around with */
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        curl_multi_timeout(multi_handle, &curl_timeo);
        if(curl_timeo >= 0) {
            timeout.tv_sec = curl_timeo / 1000;
            if(timeout.tv_sec > 1)
                timeout.tv_sec = 1;
            else
                timeout.tv_usec = (curl_timeo % 1000) * 1000;
        }

        /* get file descriptors from the transfers */
        mc = curl_multi_fdset(multi_handle, &fdread, &fdwrite, &fdexcep, &maxfd);
        if(mc != CURLM_OK) {
            fprintf(stderr, "curl_multi_fdset() failed, code %d.\n", mc);
            break;
        }
        /* On success the value of maxfd is guaranteed to be >= -1. We call
       select(maxfd + 1, ...); specially in case of (maxfd == -1) there are
       no fds ready yet so we call select(0, ...) --or Sleep() on Windows--
       to sleep 100ms, which is the minimum suggested value in the
       curl_multi_fdset() doc. */
        if(maxfd == -1)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        else {
            /* Note that on some platforms 'timeout' may be modified by select().
         If you need access to the original value save a copy beforehand. */
            rc = select(maxfd + 1, &fdread, &fdwrite, &fdexcep, &timeout);
        }

        switch(rc) {
        case -1:
            /* select error */
            break;
        case 0: /* timeout */
        default: /* action */
            curl_multi_perform(multi_handle, &still_running);
            break;
        }
    }
}
