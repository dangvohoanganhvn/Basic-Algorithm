/***************************************************************************
 *                                  _   _ ____  _
 *  Project                     ___| | | |  _ \| |
 *                             / __| | | | |_) | |
 *                            | (__| |_| |  _ <| |___
 *                             \___|\___/|_| \_\_____|
 *
 * Copyright (C) 1998 - 2018, Daniel Stenberg, <daniel@haxx.se>, et al.
 *
 * This software is licensed as described in the file COPYING, which
 * you should have received as part of this distribution. The terms
 * are also available at https://curl.haxx.se/docs/copyright.html.
 *
 * You may opt to use, copy, modify, merge, publish, distribute and/or sell
 * copies of the Software, and permit persons to whom the Software is
 * furnished to do so, under the terms of the COPYING file.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 ***************************************************************************/
/* <DESC>
 * A basic application source code using the multi interface doing two
 * transfers in parallel.
 * </DESC>
 */
#include<iostream>
#include <stdio.h>
#include <string.h>
#include <sstream>
/* somewhat unix-specific */
#include <sys/time.h>
#include <unistd.h>

/* curl stuff */
#include <curl/curl.h>
#include "httpdownloader.h"
#include <unistd.h>
#include <chrono>
#include <thread>
#include <fstream>
/*
 * Download a HTTP file and upload an FTP file simultaneously.
 */


#define HANDLECOUNT 2  /* Number of simultaneous transfers */
#define HTTP_HANDLE 0   /* Index for the HTTP transfer */
#define FTP_HANDLE 1    /* Index for the FTP transfer */

using namespace std;
size_t write_data(void *buffer, size_t size, size_t nmemb, void *output)
{
    string data((const char*) buffer, (size_t) size * nmemb);
    *((stringstream*) output) << data << endl;
    return size * nmemb;
}
int main(void)
{
    std::ofstream m_myfile,m_myfile_1;
    m_myfile.open("/Users/cpu11905/Desktop/data/test",std::ofstream::out);
    m_myfile_1.open("/Users/cpu11905/Desktop/data/test_1",std::ofstream::out);
    HTTPDownloader downloader;
    string out;
    stringstream test;
    stringstream test_1;
    downloader.Init_Multi_Curl();
    downloader.download("https://example.com",test);
    downloader.download("https://google.com",test_1);
    downloader.Exec();
    string data(test.str());
    string data_1(test_1.str());
    m_myfile.write (data.c_str(),data.length());
    m_myfile_1.write (data_1.c_str(),data_1.length());
    m_myfile.close();
    m_myfile_1.close();

    //    /* See how the transfers went */
    //    while((msg = curl_multi_info_read(multi_handle, &msgs_left)))
    //    {
    //        if(msg->msg == CURLMSG_DONE) {
    //            int idx;

    //            /* Find out which handle this message is about */
    //            for(idx = 0; idx<HANDLECOUNT; idx++) {
    //                int found = (msg->easy_handle == handles[idx]);
    //                if(found)
    //                    break;
    //            }

    //            switch(idx) {
    //            case HTTP_HANDLE:
    //                printf("HTTP transfer completed with status %d\n", msg->data.result);
    //                break;
    //            case FTP_HANDLE:
    //                printf("FTP transfer completed with status %d\n", msg->data.result);
    //                break;
    //            }
    //        }
    //    }

    //    curl_multi_cleanup(multi_handle);

    //    /* Free the CURL handles */
    //    for(i = 0; i<HANDLECOUNT; i++)
    //        curl_easy_cleanup(handles[i]);

    return 0;
}
