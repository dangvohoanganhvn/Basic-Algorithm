
#ifndef HTTPDOWNLOADER_HPP
#define HTTPDOWNLOADER_HPP
#include <string>
#include <curl/curl.h>
#include <vector>
#include <sstream>

/**
 * A non-threadsafe simple libcURL-easy based HTTP downloader
 */
class HTTPDownloader {
public:
    HTTPDownloader();
    ~HTTPDownloader();
    /**
     * Download a file using HTTP GET and store in in a std::string
     * @param url The URL to download
     * @return The download result
     */
    void download(const std::string& url,std::stringstream& data);

    CURL* Add_New_Action();
    void Init_Multi_Curl();
    void Init_New_Curl(CURL* curl);
    void Exec();
    std::stringstream out;
private:
    int num_curl=0;
    std::vector<CURL*> handles;
    CURLM *multi_handle;
    int  still_running=0;
    FILE *file=fopen("/Users/cpu11905/Desktop/data/header","wb");



};
#endif  /* HTTPDOWNLOADER_HPP */
