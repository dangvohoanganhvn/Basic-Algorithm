
#ifndef HTTPDOWNLOADER_HPP
#define HTTPDOWNLOADER_HPP
#include <string>
#include <curl/curl.h>
#include <vector>
#include <sstream>
#include <map>
#include <mutex>
/**
 * A non-threadsafe simple libcURL-easy based HTTP downloader
 */
class HTTPDownloader {
public:
    HTTPDownloader();
    ~HTTPDownloader();
    /**
     * Download a file using HTTP GET and store in in a std::string
     * @param url The URL to download
     * @return The download result
     */
    void download(const std::string& url,std::string data, bool is_resume,bool is_timeout);

    CURL* Add_New_Action(const std::string& url);
    void Init_Multi_Curl();
    void Init_New_Curl(CURL* curl);
    void Exec();
    std::mutex m_mtx;
    bool is_set=false;

private:
    int num_curl=0;
    std::vector<CURL*> handles;
    CURLM *multi_handle;
    int  still_running=0;
    std::map<CURL*,std::string> URL_Store;
    std::map<CURL*,std::string> DIR_Store;
    std::map<CURL*,bool> Is_Timeout; // This varible is used for distinguishing the Timeout case and incorrect URLcase

};
#endif  /* HTTPDOWNLOADER_HPP */
