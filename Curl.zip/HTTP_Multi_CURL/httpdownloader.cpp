
#include "httpdownloader.h"
#include <curl/easy.h>
#include <curl/curlbuild.h>
#include <chrono>
#include <thread>
#include <fstream>
#include <iostream>
using namespace std;

std::ifstream::pos_type filesize(const std::string& filename)
{
    std::ifstream in(filename, std::ifstream::ate | std::ifstream::binary);
    auto size=in.tellg();
    in.close();
    return size;
}

size_t write(void *buffer, size_t size, size_t nmemb, void *output)
{
    string data((const char*) buffer, (size_t) size * nmemb);
    std::ofstream m_myfile;
    string name=(*(string*)output);
    m_myfile.open(name,std::ios::app);
    m_myfile.write (data.c_str(),data.length());
    m_myfile.close();
    return size * nmemb;
}
HTTPDownloader::HTTPDownloader()
{

}
HTTPDownloader::~HTTPDownloader() {
    curl_multi_cleanup(multi_handle);
    for(auto i:handles)
    {
        curl_easy_cleanup(i);
    }
    handles.clear();

}
void HTTPDownloader::download(const std::string& url,std::string data, bool is_resume,bool is_timeout) {
    auto curl=Add_New_Action(url);
    std::ofstream m_myfile;
    m_myfile.open(url,std::ios::app);
    m_myfile.close();
    URL_Store[handles.back()]=url;
    DIR_Store[handles.back()]=data;
    Is_Timeout[handles.back()]=false;

    if(is_timeout==true)
    {
        Is_Timeout[handles.back()]=true;
    }
    if(is_resume==true)
    {
        long size=filesize(data);
        curl_easy_setopt(curl, CURLOPT_RESUME_FROM,size );
    }
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 300); //bytes/sec
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 3);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L); // tell the lib follow the redirection automatically
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1); //Prevent "longjmp causes uninitialized stack frame" bug
    // curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "GET");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &DIR_Store[handles.back()]);
    Init_New_Curl(curl);
}

CURL* HTTPDownloader::Add_New_Action(const std::string& url)
{
    handles.push_back(curl_easy_init());
    num_curl++;
    return handles.back();
}

void HTTPDownloader::Init_Multi_Curl()
{
    multi_handle = curl_multi_init();
}

void HTTPDownloader::Init_New_Curl(CURL* curl)
{

    curl_multi_add_handle(multi_handle, curl);
    curl_multi_perform(multi_handle, &still_running);

}

void HTTPDownloader::Exec()
{
    CURLMsg *msg;
    int msgs_left;

    while(still_running)
    {
        int num_running=still_running;
        struct timeval timeout;
        int rc; /* select() return code */
        CURLMcode mc; /* curl_multi_fdset() return code */
        CURLMcode res;
        fd_set fdread;
        fd_set fdwrite;
        fd_set fdexcep;
        int maxfd = -1;
        long curl_timeo = -1;
        FD_ZERO(&fdread);
        FD_ZERO(&fdwrite);
        FD_ZERO(&fdexcep);

        /* set a suitable timeout to play around with */
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        curl_multi_timeout(multi_handle, &curl_timeo);
        if(curl_timeo >= 0) {
            timeout.tv_sec = curl_timeo / 1000;
            if(timeout.tv_sec > 1)
                timeout.tv_sec = 1;
            else
                timeout.tv_usec = (curl_timeo % 1000) * 1000;
        }

        /* get file descriptors from the transfers */
        mc = curl_multi_fdset(multi_handle, &fdread, &fdwrite, &fdexcep, &maxfd);
        if(mc != CURLM_OK) {
            fprintf(stderr, "curl_multi_fdset() failed, code %d.\n", mc);
            break;
        }

        if(maxfd == -1)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        else {

            rc = select(maxfd + 1, &fdread, &fdwrite, &fdexcep, &timeout);
        }
        switch(rc)
        {
        case -1:
            /* select error */
            break;
        case 0: /* timeout */
        default: /* action */
            m_mtx.lock();
            res= curl_multi_perform(multi_handle, &still_running);
            m_mtx.unlock();

            break;
        }
        while((msg = curl_multi_info_read(multi_handle, &msgs_left)))
        {
            if(msg->msg == CURLMSG_DONE)
            {
                if(msg->data.result==CURLE_OK)
                    /* Find out which handle this message is about */
                {
                    cout<<"Completed Dowload "<< URL_Store[msg->easy_handle]<<std::endl;
                    m_mtx.lock();
                    curl_multi_remove_handle(multi_handle,msg->easy_handle);
                    curl_easy_cleanup(msg->easy_handle);
                    m_mtx.unlock();
                }
                else if((msg->data.result==CURLE_COULDNT_RESOLVE_HOST||
                         msg->data.result==CURLE_URL_MALFORMAT||
                         msg->data.result==CURLE_COULDNT_CONNECT)&&
                         Is_Timeout[msg->easy_handle]==false )
                {
                    cout<<"Please check your Network or URL: "<< URL_Store[msg->easy_handle]<<std::endl;
                    m_mtx.lock();
                    curl_multi_remove_handle(multi_handle,msg->easy_handle);
                    m_mtx.unlock();
                }
                else
                {
                    // cout<<"Retry to Download "<< URL_Store[msg->easy_handle]<<std::endl;
                    m_mtx.lock();
                    curl_multi_remove_handle(multi_handle,msg->easy_handle);
                    m_mtx.unlock();
                    download(URL_Store[msg->easy_handle],DIR_Store[msg->easy_handle],true,true);
                    URL_Store.erase(msg->easy_handle);
                    DIR_Store.erase(msg->easy_handle);
                    Is_Timeout.erase(msg->easy_handle);
                    // std::this_thread::sleep_for(std::chrono::milliseconds(10));
                }
            }

        }
    }
}
