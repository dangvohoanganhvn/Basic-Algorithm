#include<iostream>
#include <stdio.h>
#include <string.h>
#include <sstream>
/* somewhat unix-specific */
#include <sys/time.h>
#include <unistd.h>

/* curl stuff */
#include <curl/curl.h>
#include "httpdownloader.h"
#include <unistd.h>
#include <thread>
#include <fstream>
#include <queue>
#include <mutex>
#include <map>
using namespace std;

string GetFileName (const string& str)
{

    std::size_t found = str.find_last_of("/");
    if(found== string::npos)
    {
        return ".html";
    }
    return str.substr(found+1);
}

std::string datetime()
{
    time_t rawtime;
    struct tm * timeinfo;
    char buffer[80];

    time (&rawtime);
    timeinfo = localtime(&rawtime);

    strftime(buffer,80,"%d_%m_%Y_%H_%M_%S",timeinfo);
    return std::string(buffer);
}

int main(void)
{
    string homedir = getenv("HOME");
    cout<<homedir<<endl;
    queue<string> URL;
    map<string,string> Url_Dir;
    curl_global_init(CURL_GLOBAL_ALL);
    HTTPDownloader *downloader=new HTTPDownloader();
    downloader->Init_Multi_Curl();


    thread terminal( [=]()
    {
        while(1)
        {
            mutex mtx;
            string url;
            string dir;

            cout<<"Please input the link you want to download"<<endl;
            getline(cin, // data from keyboard
                    url); //the link you want to down load

            string file_name=GetFileName(url);
            dir=homedir+"/Downloads/"+datetime()+"_"+file_name;
            downloader->m_mtx.lock();
            downloader->download(url, // URL link
                                 dir, // directory you want to save
                                 false,false);// This is not resumeing download

            downloader->is_set=true;
            downloader->m_mtx.unlock();
            std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        }
    });

    thread Exec_Download( [=]()
    {
        while(1)
        {
            downloader->m_mtx.lock();
            bool stt=downloader->is_set;
            downloader->m_mtx.unlock();
            if(stt==true)
            {
                downloader->Exec();
                stt=false;
            }
             std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
    });

    terminal.join();
    Exec_Download.join();

    return 0;
}

